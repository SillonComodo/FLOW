import { GoogleGenAI } from "@google/genai";
import { ChatMessage } from '../types';

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

export const generateAIResponse = async (
  history: ChatMessage[], 
  currentMessage: string, 
  documentContext: string = ''
): Promise<string> => {
  if (!apiKey) {
    return "Error: API Key no encontrada. Por favor verifica tu configuración.";
  }

  try {
    const model = 'gemini-2.5-flash';
    
    // Construct system instruction with context
    let systemInstruction = "Eres un asistente inteligente para estudiantes universitarios. Eres experto en programación, redacción académica y gestión de tiempo.";
    
    if (documentContext) {
      systemInstruction += `\n\nCONTEXTO DEL DOCUMENTO ACTUAL:\n${documentContext}\n\nUsa este contexto para responder las preguntas del usuario si es relevante.`;
    }

    const contents = [
      ...history.map(msg => ({
        role: msg.role,
        parts: [{ text: msg.text }]
      })),
      {
        role: 'user',
        parts: [{ text: currentMessage }]
      }
    ];

    const response = await ai.models.generateContent({
      model,
      contents,
      config: {
        systemInstruction,
        temperature: 0.7,
      }
    });

    return response.text || "No se pudo generar una respuesta.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Ocurrió un error al conectar con el servicio de IA.";
  }
};

export const summarizeText = async (text: string): Promise<string> => {
    if (!apiKey) return "API Key faltante.";
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `Resume el siguiente texto en 3 puntos clave:\n\n${text}`
        });
        return response.text || "";
    } catch (e) {
        return "Error al resumir.";
    }
}